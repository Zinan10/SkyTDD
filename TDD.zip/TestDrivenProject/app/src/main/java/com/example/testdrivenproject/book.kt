package com.example.testdrivenproject

data class Book(var reference: String = "", var title: String = "", var review: String = "")
